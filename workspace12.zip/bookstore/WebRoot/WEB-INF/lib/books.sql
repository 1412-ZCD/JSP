-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.15-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema books
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ books;
USE books;

--
-- Table structure for table `books`.`account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL auto_increment,
  `balance` double default NULL,
  `creditcard` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`account`
--

/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`,`balance`,`creditcard`) VALUES 
 (1,7500,'12345678901'),
 (3,20000,'001'),
 (4,20000,'001'),
 (5,20000,'001');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;


--
-- Table structure for table `books`.`authorisbn`
--

DROP TABLE IF EXISTS `authorisbn`;
CREATE TABLE `authorisbn` (
  `authorID` int(11) default NULL,
  `isbn` varchar(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`authorisbn`
--

/*!40000 ALTER TABLE `authorisbn` DISABLE KEYS */;
INSERT INTO `authorisbn` (`authorID`,`isbn`) VALUES 
 (1,'0130895725'),
 (1,'0132261197'),
 (1,'0130895717'),
 (1,'0135289106'),
 (1,'0139163050'),
 (1,'013028419x'),
 (1,'0130161438'),
 (1,'0130856118'),
 (1,'0130125075'),
 (1,'0138993947'),
 (1,'0130852473'),
 (1,'0130829277'),
 (1,'0134569555'),
 (1,'0130829293'),
 (1,'0130284173'),
 (1,'0130284181'),
 (1,'0130895601'),
 (2,'0130895725'),
 (2,'0132261197'),
 (2,'0130895717'),
 (2,'0135289106'),
 (2,'0139163050'),
 (2,'013028419x'),
 (2,'0130161438'),
 (2,'0130856118'),
 (2,'0130125075'),
 (2,'0138993947'),
 (2,'0130852473'),
 (2,'0130829277'),
 (2,'0134569555'),
 (2,'0130829293'),
 (2,'0130284173'),
 (2,'0130284181'),
 (2,'0130895601'),
 (3,'013028419x'),
 (3,'0130161438'),
 (3,'0130856118'),
 (3,'0134569555'),
 (3,'0130829293'),
 (3,'0130284173'),
 (3,'0130284181'),
 (4,'0130895601');
/*!40000 ALTER TABLE `authorisbn` ENABLE KEYS */;


--
-- Table structure for table `books`.`authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `authorID` int(11) NOT NULL auto_increment,
  `firstName` varchar(20) default NULL,
  `lastName` varchar(30) default NULL,
  PRIMARY KEY  (`authorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`authors`
--

/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` (`authorID`,`firstName`,`lastName`) VALUES 
 (1,'Harvey','Deitel'),
 (2,'Paul','Deitel'),
 (3,'Tem','Nieto'),
 (4,'Sean','Santry');
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;


--
-- Table structure for table `books`.`bookorder`
--

DROP TABLE IF EXISTS `bookorder`;
CREATE TABLE `bookorder` (
  `orderId` int(11) NOT NULL auto_increment,
  `username` varchar(20) default NULL,
  `zipcode` varchar(8) default NULL,
  `phone` varchar(20) default NULL,
  `creditcard` varchar(20) default NULL,
  `total` double default NULL,
  PRIMARY KEY  (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`bookorder`
--

/*!40000 ALTER TABLE `bookorder` DISABLE KEYS */;
INSERT INTO `bookorder` (`orderId`,`username`,`zipcode`,`phone`,`creditcard`,`total`) VALUES 
 (1,'admin','226007','8888866666','12345678901',50),
 (2,'admin','226007','8888866666','12345678901',118.5),
 (3,'admin','226007','88886666','12345678901',100),
 (7,'admin','226007','12345678','12345678901',390),
 (8,'ww','222','333','4444444',86),
 (9,'ee','ee','ee','ee',88.4000015258789);
/*!40000 ALTER TABLE `bookorder` ENABLE KEYS */;


--
-- Table structure for table `books`.`publishers`
--

DROP TABLE IF EXISTS `publishers`;
CREATE TABLE `publishers` (
  `publisherID` int(11) NOT NULL auto_increment,
  `publisherName` varchar(30) default NULL,
  PRIMARY KEY  (`publisherID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`publishers`
--

/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` (`publisherID`,`publisherName`) VALUES 
 (1,'Prentice Hall'),
 (2,'Prentice Hall PTG');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;


--
-- Table structure for table `books`.`titles`
--

DROP TABLE IF EXISTS `titles`;
CREATE TABLE `titles` (
  `isbn` varchar(20) character set utf8 collate utf8_bin NOT NULL,
  `title` varchar(100) default NULL,
  `editionNumber` int(11) default NULL,
  `copyright` varchar(4) default NULL,
  `publisherID` int(11) default NULL,
  `imageFile` varchar(100) default NULL,
  `price` double default NULL,
  `summary` varchar(200) default NULL,
  PRIMARY KEY  (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`titles`
--

/*!40000 ALTER TABLE `titles` DISABLE KEYS */;
INSERT INTO `titles` (`isbn`,`title`,`editionNumber`,`copyright`,`publisherID`,`imageFile`,`price`,`summary`) VALUES 
 ('0123456677','JavaEE编程技术',1,'2002',2,'vbctc1.jpg',38.4000015258789,NULL),
 ('0135289106','C++ 程序设计',2,'1998',1,'cpphtp2.jpg',50,NULL),
 ('0138993947','Java How to Program (Java 1.1)',2,'1998',1,'jhtp2.jpg',50,NULL),
 ('0139163050','The Complete C++ Training Course',3,'2001',2,'cppctc3.jpg',110,NULL),
 ('9787030207357','Web编程技术JSP XML JAVAEE',1,'2008',1,'xmlhtp1.jpg',36,NULL),
 ('9787030207358','Web编程技术JSP XML JAVAEE',1,'2008',1,'xmlhtp1.jpg',36,NULL),
 ('9787115170026','精通JavaEE项目案例',1,'2007',1,'iw3htp1.jpg',70,NULL),
 ('9787121062629','EJB JPA数据库持久层开发',3,'2008',2,'javactc3.jpg',49,NULL),
 ('9787121072984','Java Web整合开发与项目实战',1,'2009',1,'perlhtp1.jpg',49,NULL),
 ('9787121072985','Flex 3 RIA开发详解与精深实践',1,'2009',1,'ebechtp1.jpg',44,NULL),
 ('9787121072986','精通EJB3.0',2,'2006',2,'javactc2.jpg',100,NULL),
 ('9787121072987','The Complete精通Spring',1,'2008',2,'vbctc1.jpg',47,NULL);
INSERT INTO `titles` (`isbn`,`title`,`editionNumber`,`copyright`,`publisherID`,`imageFile`,`price`,`summary`) VALUES 
 ('9787811232417','JavaEE编程技术',3,'2008',1,'jhtp3.jpg',27.2,NULL);
/*!40000 ALTER TABLE `titles` ENABLE KEYS */;


--
-- Table structure for table `books`.`userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `userId` int(11) NOT NULL auto_increment,
  `loginname` varchar(20) default NULL,
  `password` varchar(10) default NULL,
  PRIMARY KEY  (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`.`userinfo`
--

/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` (`userId`,`loginname`,`password`) VALUES 
 (1,'admin','admin');
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
