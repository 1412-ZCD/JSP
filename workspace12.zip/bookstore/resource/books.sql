/*
MySQL Data Transfer
Source Host: localhost
Source Database: books
Target Host: localhost
Target Database: books
Date: 2013-10-26 6:32:01
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL auto_increment,
  `balance` double default NULL,
  `creditcard` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE account CONVERT TO CHARACTER SET utf8;



-- ----------------------------
-- Table structure for authorisbn
-- ----------------------------
DROP TABLE IF EXISTS `authorisbn`;
CREATE TABLE `authorisbn` (
  `authorID` int(11) default NULL,
  `isbn` varchar(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE authorisbn CONVERT TO CHARACTER SET utf8;


-- ----------------------------
-- Table structure for authors
-- ----------------------------
DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `authorID` int(11) NOT NULL auto_increment,
  `firstName` varchar(20) default NULL,
  `lastName` varchar(30) default NULL,
  PRIMARY KEY  (`authorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE authors CONVERT TO CHARACTER SET utf8;


-- ----------------------------
-- Table structure for bookorder
-- ----------------------------
DROP TABLE IF EXISTS `bookorder`;
CREATE TABLE `bookorder` (
  `orderId` int(11) NOT NULL auto_increment,
  `username` varchar(20) default NULL,
  `zipcode` varchar(8) default NULL,
  `phone` varchar(20) default NULL,
  `creditcard` varchar(20) default NULL,
  `total` double default NULL,
  PRIMARY KEY  (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE bookorder CONVERT TO CHARACTER SET utf8;


-- ----------------------------
-- Table structure for publishers
-- ----------------------------
DROP TABLE IF EXISTS `publishers`;
CREATE TABLE `publishers` (
  `publisherID` int(11) NOT NULL auto_increment,
  `publisherName` varchar(30) default NULL,
  PRIMARY KEY  (`publisherID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE publishers CONVERT TO CHARACTER SET utf8;


-- ----------------------------
-- Table structure for titles
-- ----------------------------
DROP TABLE IF EXISTS `titles`;
CREATE TABLE `titles` (
  `isbn` varchar(20) character set utf8 collate utf8_bin NOT NULL,
  `title` varchar(100) default NULL,
  `editionNumber` int(11) default NULL,
  `copyright` varchar(4) default NULL,
  `publisherID` int(11) default NULL,
  `imageFile` varchar(100) default NULL,
  `price` double default NULL,
  `summary` varchar(200) default NULL,
  PRIMARY KEY  (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `titles` CONVERT TO CHARACTER SET utf8;


-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `userId` int(11) NOT NULL auto_increment,
  `loginname` varchar(20) default NULL,
  `password` varchar(10) default NULL,
  PRIMARY KEY  (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `account` VALUES ('1', '7500', '12345678901');
INSERT INTO `account` VALUES ('3', '20000', '001');
INSERT INTO `account` VALUES ('4', '20000', '001');
INSERT INTO `account` VALUES ('5', '20000', '001');
INSERT INTO `authorisbn` VALUES ('1', '0130895725');
INSERT INTO `authorisbn` VALUES ('1', '0132261197');
INSERT INTO `authorisbn` VALUES ('1', '0130895717');
INSERT INTO `authorisbn` VALUES ('1', '0135289106');
INSERT INTO `authorisbn` VALUES ('1', '0139163050');
INSERT INTO `authorisbn` VALUES ('1', '013028419x');
INSERT INTO `authorisbn` VALUES ('1', '0130161438');
INSERT INTO `authorisbn` VALUES ('1', '0130856118');
INSERT INTO `authorisbn` VALUES ('1', '0130125075');
INSERT INTO `authorisbn` VALUES ('1', '0138993947');
INSERT INTO `authorisbn` VALUES ('1', '0130852473');
INSERT INTO `authorisbn` VALUES ('1', '0130829277');
INSERT INTO `authorisbn` VALUES ('1', '0134569555');
INSERT INTO `authorisbn` VALUES ('1', '0130829293');
INSERT INTO `authorisbn` VALUES ('1', '0130284173');
INSERT INTO `authorisbn` VALUES ('1', '0130284181');
INSERT INTO `authorisbn` VALUES ('1', '0130895601');
INSERT INTO `authorisbn` VALUES ('2', '0130895725');
INSERT INTO `authorisbn` VALUES ('2', '0132261197');
INSERT INTO `authorisbn` VALUES ('2', '0130895717');
INSERT INTO `authorisbn` VALUES ('2', '0135289106');
INSERT INTO `authorisbn` VALUES ('2', '0139163050');
INSERT INTO `authorisbn` VALUES ('2', '013028419x');
INSERT INTO `authorisbn` VALUES ('2', '0130161438');
INSERT INTO `authorisbn` VALUES ('2', '0130856118');
INSERT INTO `authorisbn` VALUES ('2', '0130125075');
INSERT INTO `authorisbn` VALUES ('2', '0138993947');
INSERT INTO `authorisbn` VALUES ('2', '0130852473');
INSERT INTO `authorisbn` VALUES ('2', '0130829277');
INSERT INTO `authorisbn` VALUES ('2', '0134569555');
INSERT INTO `authorisbn` VALUES ('2', '0130829293');
INSERT INTO `authorisbn` VALUES ('2', '0130284173');
INSERT INTO `authorisbn` VALUES ('2', '0130284181');
INSERT INTO `authorisbn` VALUES ('2', '0130895601');
INSERT INTO `authorisbn` VALUES ('3', '013028419x');
INSERT INTO `authorisbn` VALUES ('3', '0130161438');
INSERT INTO `authorisbn` VALUES ('3', '0130856118');
INSERT INTO `authorisbn` VALUES ('3', '0134569555');
INSERT INTO `authorisbn` VALUES ('3', '0130829293');
INSERT INTO `authorisbn` VALUES ('3', '0130284173');
INSERT INTO `authorisbn` VALUES ('3', '0130284181');
INSERT INTO `authorisbn` VALUES ('4', '0130895601');
INSERT INTO `authors` VALUES ('1', 'Harvey', 'Deitel');
INSERT INTO `authors` VALUES ('2', 'Paul', 'Deitel');
INSERT INTO `authors` VALUES ('3', 'Tem', 'Nieto');
INSERT INTO `authors` VALUES ('4', 'Sean', 'Santry');
INSERT INTO `bookorder` VALUES ('1', 'admin', '226007', '8888866666', '12345678901', '50');
INSERT INTO `bookorder` VALUES ('2', 'admin', '226007', '8888866666', '12345678901', '118.5');
INSERT INTO `bookorder` VALUES ('3', 'admin', '226007', '88886666', '12345678901', '100');
INSERT INTO `bookorder` VALUES ('7', 'admin', '226007', '12345678', '12345678901', '390');
INSERT INTO `bookorder` VALUES ('8', 'ww', '222', '333', '4444444', '86');
INSERT INTO `bookorder` VALUES ('9', 'ee', 'ee', 'ee', 'ee', '88.4000015258789');
INSERT INTO `publishers` VALUES ('1', 'Prentice Hall');
INSERT INTO `publishers` VALUES ('2', 'Prentice Hall PTG');
INSERT INTO `titles` VALUES ('9787121072984', 'Java Web整合开发与项目实战', '1', '2009', '1', 'perlhtp1.jpg', '49', null);
INSERT INTO `titles` VALUES ('9787121072985', 'Flex 3 RIA开发详解与精深实践', '1', '2009', '1', 'ebechtp1.jpg', '44', null);
INSERT INTO `titles` VALUES ('9787121072986', '精通EJB3.0', '2', '2006', '2', 'javactc2.jpg', '64', null);
INSERT INTO `titles` VALUES ('9787811010101', 'JavaEE编程技术', '1', '2002', '2', 'vbctc1.jpg', '38', null);
INSERT INTO `titles` VALUES ('9787811010102', 'C++ 程序设计', '2', '1998', '1', 'cpphtp2.jpg', '50', null);
INSERT INTO `titles` VALUES ('9787811010103', 'Java How to Program', '2', '1998', '1', 'jhtp2.jpg', '50', null);
INSERT INTO `titles` VALUES ('9787811010121', 'The Complete C++ Training Course', '3', '2001', '2', 'cppctc3.jpg', '54', null);
INSERT INTO `titles` VALUES ('9787811014322', 'Web编程技术', '1', '2008', '1', 'xmlhtp1.jpg', '36', null);
INSERT INTO `titles` VALUES ('9787811019877', 'EJB JPA数据库持久层开发', '3', '2008', '2', 'javactc3.jpg', '49', null);
INSERT INTO `titles` VALUES ('9787811078661', '精通JavaEE项目案例', '1', '2007', '1', 'iw3htp1.jpg', '70', null);
INSERT INTO `userinfo` VALUES ('1', 'admin', '123');

